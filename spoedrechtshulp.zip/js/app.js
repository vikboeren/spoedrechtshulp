/* ============================================================
   SpoedRechtshulp — js/app.js
   Dit bestand ontbrak volledig in de repo, waardoor alle knoppen
   op de site (menu, cookiebanner, "Start direct", triage-chat)
   niet werkten. Dit bestand herstelt alle functionaliteit.
   ============================================================ */

/* ---------- CONFIG ---------- */

// Bestaand, al live WhatsApp-nummer (zelfde nummer als de floating knop).
// Dit is de gegarandeerde fallback zodat een aanvraag nooit verloren gaat.
const WHATSAPP_NUMBER = '31682756789';

// Vul deze in via emailjs.com → Account → API Keys / Email Services / Templates.
// Zolang deze op 'YOUR_...' staan, wordt alleen via WhatsApp verstuurd.
const EMAILJS_CONFIG = {
  serviceId: 'service_d5o9cir',
  templateId: 'template_uyc8vio',
  publicKey: 'AjC1aOiOrUoy_0r-k'
};
const EMAILJS_ENABLED = Object.values(EMAILJS_CONFIG).every((v) => !v.startsWith('YOUR_'));

if (EMAILJS_ENABLED && window.emailjs) {
  emailjs.init(EMAILJS_CONFIG.publicKey);
} else if (!EMAILJS_ENABLED) {
  console.warn('[SpoedRechtshulp] EmailJS niet geconfigureerd (js/app.js → EMAILJS_CONFIG). Aanvragen gaan alleen via WhatsApp.');
}

/* ---------- NAVIGATIEMENU (mobiel) ---------- */

function toggleMenu() {
  const nav = document.getElementById('nav-links');
  const btn = document.getElementById('nav-hamburger');
  if (!nav) return;
  const isOpen = nav.classList.toggle('open');
  if (btn) btn.setAttribute('aria-expanded', String(isOpen));
}

/* ---------- COOKIEBANNER ---------- */

const COOKIE_KEY = 'sr_cookie_consent';

function initCookieBanner() {
  const banner = document.getElementById('cookie-banner');
  if (banner && localStorage.getItem(COOKIE_KEY)) {
    banner.classList.add('hidden');
  }
}

function acceptCookies() {
  localStorage.setItem(COOKIE_KEY, 'accepted');
  document.getElementById('cookie-banner')?.classList.add('hidden');
}

function declineCookies() {
  localStorage.setItem(COOKIE_KEY, 'declined');
  document.getElementById('cookie-banner')?.classList.add('hidden');
}

/* ---------- TRIAGE-CHAT ---------- */

const TRIAGE_FLOWS = {
  rijbewijs: {
    label: 'Rijbewijs Inbeslagname',
    steps: [
      {
        question: 'Wat is op dit moment uw situatie?',
        options: [
          'Rijbewijs is zojuist ingenomen door de politie',
          'Ik heb een vorderingsbesluit van het OM ontvangen',
          'Weet ik niet precies'
        ]
      },
      {
        question: 'Wat was de reden van de inbeslagname?',
        options: ['Rijden onder invloed', '(Ernstige) snelheidsovertreding', 'Anders / weet ik niet']
      },
      {
        question: 'Heeft u uw rijbewijs beroepsmatig nodig, bijvoorbeeld voor uw werk?',
        options: ['Ja, dringend', 'Nee', 'Twijfel']
      }
    ]
  },
  auto: {
    label: 'Auto Inbeslagname',
    steps: [
      {
        question: 'Wat is op dit moment uw situatie?',
        options: [
          'Auto is zojuist in beslag genomen',
          'Ik zit al in een klaagschriftprocedure',
          'Weet ik niet precies'
        ]
      },
      {
        question: 'Wat is de reden van de inbeslagname?',
        options: ['Verdenking van een strafbaar feit', 'Ontneming / wederrechtelijk verkregen voordeel', 'Anders / weet ik niet']
      },
      {
        question: 'Hoe snel heeft u de auto weer nodig?',
        options: ['Zo snel mogelijk', 'Kan enkele dagen wachten', 'Weet ik niet']
      }
    ]
  }
};

let triageState = null;

function startTriage(topic) {
  const flow = TRIAGE_FLOWS[topic];
  const section = document.getElementById('chat-section');
  const body = document.getElementById('chat-body');
  if (!flow || !section || !body) return;

  triageState = { topic, label: flow.label, answers: [] };

  section.style.display = 'block';
  body.innerHTML = '';

  const badge = document.getElementById('chat-topic-badge');
  if (badge) {
    badge.textContent = flow.label;
    badge.style.display = 'inline-block';
  }
  const progressWrap = document.getElementById('chat-progress');
  if (progressWrap) progressWrap.style.display = 'flex';

  updateProgress(0, flow.steps.length + 1);
  section.scrollIntoView({ behavior: 'smooth', block: 'start' });

  addBotMessage(
    `Goed, u heeft "${flow.label}" geselecteerd. Ik stel u een paar korte vragen zodat wij direct de juiste hulp kunnen bieden.`,
    () => askStep(0)
  );
}

function askStep(index) {
  const flow = TRIAGE_FLOWS[triageState.topic];

  if (index >= flow.steps.length) {
    showContactForm();
    return;
  }

  const step = flow.steps[index];
  updateProgress(index + 1, flow.steps.length + 1);

  addBotMessage(step.question, () => {
    addOptions(step.options, (choice) => {
      addUserMessage(choice);
      triageState.answers.push({ question: step.question, answer: choice });
      askStep(index + 1);
    });
  });
}

function showContactForm() {
  const flow = TRIAGE_FLOWS[triageState.topic];
  updateProgress(flow.steps.length + 1, flow.steps.length + 1);

  addBotMessage('Bedankt. Laatste stap: vul uw gegevens in, dan nemen wij zo snel mogelijk contact met u op.', () => {
    const body = document.getElementById('chat-body');
    const wrap = document.createElement('div');
    wrap.className = 'msg msg-bot contact-form-wrap';
    wrap.innerHTML = `
      <div class="msg-avatar">SR</div>
      <div class="contact-form-bubble">
        <h3>Uw gegevens</h3>
        <p>Wij behandelen uw aanvraag vertrouwelijk en nemen doorgaans binnen enkele uren contact op.</p>
        <form id="triage-contact-form" novalidate>
          <div class="form-row">
            <div class="form-field">
              <label for="tf-name">Naam</label>
              <input type="text" id="tf-name" name="name" required autocomplete="name" />
            </div>
            <div class="form-field">
              <label for="tf-phone">Telefoonnummer</label>
              <input type="tel" id="tf-phone" name="phone" required autocomplete="tel" />
            </div>
            <div class="form-field">
              <label for="tf-email">E-mailadres (optioneel)</label>
              <input type="email" id="tf-email" name="email" autocomplete="email" />
            </div>
            <button type="submit" class="form-submit-btn">Verstuur aanvraag</button>
          </div>
        </form>
      </div>`;
    body.appendChild(wrap);
    scrollChatToBottom();
    wrap.querySelector('#triage-contact-form').addEventListener('submit', handleContactSubmit);
    wrap.querySelector('#tf-name').focus();
  });
}

function handleContactSubmit(e) {
  e.preventDefault();
  const form = e.target;
  const name = form.name.value.trim();
  const phone = form.phone.value.trim();
  const email = form.email.value.trim();
  if (!name || !phone) return;

  const submitBtn = form.querySelector('.form-submit-btn');
  submitBtn.disabled = true;
  submitBtn.textContent = 'Versturen...';

  const summary = triageState.answers.map((a) => `${a.question} → ${a.answer}`).join('\n');
  const lead = { topic: triageState.label, name, phone, email, summary };

  sendLead(lead).finally(() => {
    form.closest('.contact-form-wrap').remove();
    showSuccess(name);
  });
}

// Verstuurt de lead. WhatsApp is de gegarandeerde hoofdroute (nummer is al live
// op de site); EmailJS wordt er als extra, stille kopie naast gestuurd zodra
// EMAILJS_CONFIG hierboven is ingevuld.
function sendLead(lead) {
  const tasks = [];

  if (EMAILJS_ENABLED && window.emailjs) {
    tasks.push(
      emailjs
        .send(EMAILJS_CONFIG.serviceId, EMAILJS_CONFIG.templateId, {
          to_name: 'SpoedRechtshulp',
          from_name: lead.name,
          phone: lead.phone,
          email: lead.email || 'niet opgegeven',
          topic: lead.topic,
          message: lead.summary
        })
        .catch((err) => console.warn('[SpoedRechtshulp] EmailJS versturen mislukt:', err))
    );
  }

  const text = `Nieuwe aanvraag via website\nOnderwerp: ${lead.topic}\nNaam: ${lead.name}\nTelefoon: ${lead.phone}\nE-mail: ${lead.email || 'niet opgegeven'}\n\n${lead.summary}`;
  const waUrl = `https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(text)}`;
  window.open(waUrl, '_blank', 'noopener');

  return Promise.all(tasks);
}

function showSuccess(name) {
  const body = document.getElementById('chat-body');
  const wrap = document.createElement('div');
  wrap.className = 'msg msg-bot contact-form-wrap';
  wrap.innerHTML = `
    <div class="msg-avatar">SR</div>
    <div class="success-bubble">
      <div class="success-icon">✅</div>
      <h3>Bedankt, ${escapeHtml(name)}!</h3>
      <p>Uw aanvraag is ontvangen. We hebben ook een WhatsApp-gesprek voor u geopend zodat u meteen in contact staat met ons team. Wij nemen binnen 24 uur — bij spoed vaak dezelfde dag — contact met u op.</p>
    </div>`;
  body.appendChild(wrap);
  scrollChatToBottom();
  const label = document.getElementById('progress-label');
  if (label) label.textContent = 'Aanvraag voltooid';
}

/* ---------- CHAT-UI HELPERS ---------- */

function addBotMessage(text, callback) {
  const body = document.getElementById('chat-body');
  const typing = document.createElement('div');
  typing.className = 'msg msg-bot typing-bubble';
  typing.innerHTML = '<div class="msg-avatar">SR</div><div class="typing-dots"><span></span><span></span><span></span></div>';
  body.appendChild(typing);
  scrollChatToBottom();

  setTimeout(() => {
    typing.remove();
    const msg = document.createElement('div');
    msg.className = 'msg msg-bot';
    msg.innerHTML = '<div class="msg-avatar">SR</div><div class="msg-bubble"></div>';
    msg.querySelector('.msg-bubble').textContent = text;
    body.appendChild(msg);
    scrollChatToBottom();
    if (callback) callback();
  }, 550);
}

function addUserMessage(text) {
  const body = document.getElementById('chat-body');
  const msg = document.createElement('div');
  msg.className = 'msg msg-user';
  msg.innerHTML = '<div class="msg-bubble"></div>';
  msg.querySelector('.msg-bubble').textContent = text;
  body.appendChild(msg);
  scrollChatToBottom();
}

function addOptions(options, onChoose) {
  const body = document.getElementById('chat-body');
  const wrap = document.createElement('div');
  wrap.className = 'options-wrap';
  options.forEach((opt) => {
    const btn = document.createElement('button');
    btn.type = 'button';
    btn.className = 'option-btn';
    btn.textContent = opt;
    btn.addEventListener('click', () => {
      wrap.remove();
      onChoose(opt);
    });
    wrap.appendChild(btn);
  });
  body.appendChild(wrap);
  scrollChatToBottom();
}

function updateProgress(current, total) {
  const fill = document.getElementById('progress-fill');
  const label = document.getElementById('progress-label');
  if (fill) fill.style.width = `${Math.round((current / total) * 100)}%`;
  if (label) label.textContent = `Stap ${current} van ${total}`;
}

function scrollChatToBottom() {
  const body = document.getElementById('chat-body');
  if (body) body.scrollTop = body.scrollHeight;
}

function escapeHtml(str) {
  const div = document.createElement('div');
  div.textContent = str;
  return div.innerHTML;
}

/* ---------- TOEGANKELIJKHEID: Enter/Spatie op role="button" ---------- */

document.addEventListener('keydown', (e) => {
  if ((e.key === 'Enter' || e.key === ' ') && e.target.matches('[role="button"]')) {
    e.preventDefault();
    e.target.click();
  }
});

/* ---------- INIT ---------- */

document.addEventListener('DOMContentLoaded', initCookieBanner);
